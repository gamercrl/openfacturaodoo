# -*- coding: utf-8 -*-
{
    'name': 'Open Factura',
    'version': '1.0',
    'summary': 'Module for managing invoices with XML signing and server interaction',
    'sequence': 10,
    'description': 'Open Factura facilitates the creation, signing, and transmission of invoices in XML format, integrating seamlessly with external systems for compliance and verification.',
    'category': 'Accounting',
    'website': 'https://www.yourcompany.com',
    'depends': ['base'],
    'data': [
        'views/invoice_views.xml',
        'security/ir.model.access.csv',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
