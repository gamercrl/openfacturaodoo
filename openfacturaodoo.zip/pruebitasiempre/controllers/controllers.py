# -*- coding: utf-8 -*-
# from odoo import http


# class Pruebitasiempre(http.Controller):
#     @http.route('/pruebitasiempre/pruebitasiempre', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pruebitasiempre/pruebitasiempre/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('pruebitasiempre.listing', {
#             'root': '/pruebitasiempre/pruebitasiempre',
#             'objects': http.request.env['pruebitasiempre.pruebitasiempre'].search([]),
#         })

#     @http.route('/pruebitasiempre/pruebitasiempre/objects/<model("pruebitasiempre.pruebitasiempre"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pruebitasiempre.object', {
#             'object': obj
#         })

