# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class pruebitasiempre(models.Model):
#     _name = 'pruebitasiempre.pruebitasiempre'
#     _description = 'pruebitasiempre.pruebitasiempre'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100


from odoo import models, fields, api
import xml.etree.ElementTree as ET
from signxml import XMLSigner, methods

class Invoice(models.Model):
    _name = 'module.invoice'
    _description = 'Invoice'

    customer_id = fields.Many2one('res.partner', string='Customer')
    invoice_date = fields.Date(string='Invoice Date')
    details = fields.Text(string='Details')
    xml_content = fields.Text(string='XML Content')
    signed_xml = fields.Text(string='Signed XML')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('received', 'Received')
    ], default='draft')

    @api.model
    def create_xml(self):
        root = ET.Element('Invoice')
        ET.SubElement(root, 'CustomerID').text = str(self.customer_id.id)
        ET.SubElement(root, 'InvoiceDate').text = str(self.invoice_date)
        ET.SubElement(root, 'Details').text = self.details
        self.xml_content = ET.tostring(root, encoding='unicode')
        return self.xml_content

    @api.model
    def sign_xml(self):
        root = ET.fromstring(self.xml_content)
        signer = XMLSigner(method=methods.enveloped, signature_algorithm='rsa-sha256')
        self.signed_xml = signer.sign(root, key=self.env['res.config.settings'].get_xml_signing_key())
        return self.signed_xml

    @api.model
    def send_xml(self):
        # Example placeholder for sending XML
        # Implement your server communication here
        pass

    @api.onchange('customer_id', 'invoice_date', 'details')
    def _onchange_fields(self):
        if self.customer_id and self.invoice_date and self.details:
            self.create_xml()
            self.sign_xml()
